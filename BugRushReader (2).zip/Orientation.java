package org.example;

public enum Orientation {
    Horizontal,
    Vertical
}